#include<stdio.h> ///header file
void main () ///main function
{
    int i; ///variable declare
    for (i=0;i<100;i++) ///for loop
    {
     if(i%2 ==0) ///condition
      printf("%d   ",i); ///print function

    }
    return 0; ///no return
}
